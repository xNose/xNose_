What am I trying to do..
..What's happening 
