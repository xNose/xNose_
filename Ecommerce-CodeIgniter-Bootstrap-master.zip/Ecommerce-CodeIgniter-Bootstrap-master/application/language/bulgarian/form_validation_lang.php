<?php

$lang['required'] = 'Required fields';